# Demonstrates a constant

MEOWS = 3

for _ in range(MEOWS):
    print("meow")
