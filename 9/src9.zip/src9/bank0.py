# Implements a bank account

balance = 0


def main():
    print("Balance:", balance)


if __name__ == "__main__":
    main()
