# Unpacks a list

first, _ = input("What's your name? ").split(" ")
print(f"hello, {first}")
