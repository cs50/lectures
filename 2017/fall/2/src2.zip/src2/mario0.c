// Prints four question marks

#include <stdio.h>

int main(void)
{
    printf("????\n");
}
