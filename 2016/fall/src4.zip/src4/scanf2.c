#include <stdio.h>

int main(void)
{
    char s[16];
    printf("s: ");
    scanf("%s", s);
    printf("s: %s\n", s);
}
